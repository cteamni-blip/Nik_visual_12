package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

@Environment(EnvType.CLIENT)
public class ComboHudRenderer {
    private int combo;
    private long lastHitMs;
    private float appear;
    private float pop;
    private boolean wasSwing;
    private int lastHurt;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.comboHud || mc.player == null) {
            combo = 0;
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastHitMs > 2200) {
            combo = 0;
        }

        boolean swinging = mc.player.handSwinging;
        Entity focused = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            focused = ((EntityHitResult) mc.crosshairTarget).getEntity();
        }

        if (swinging && !wasSwing && focused instanceof LivingEntity le && le.isAlive()) {
            int ht = le.hurtTime;
            // new swing while looking at living entity — count if they recently took damage or will
            if (ht > 0 || lastHurt > 0) {
                combo++;
                lastHitMs = now;
                pop = 1f;
            } else {
                // optimistic count on clean swing (PvP servers lag)
                combo++;
                lastHitMs = now;
                pop = 1f;
            }
        }
        if (focused instanceof LivingEntity le) lastHurt = le.hurtTime;
        wasSwing = swinging;
        pop = Anim.approach(pop, 0f, 0.12f);
        appear = Anim.approach(appear, combo > 1 ? 1f : 0f, 0.18f);
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f || combo < 2) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        float a = Anim.easeOutCubic(appear);
        float scale = 1f + 0.25f * pop * Anim.spring(pop);

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2 + 28;

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(cx, cy);
        g.getMatrices().scale(scale, scale);

        String text = combo + "x";
        int w = mc.textRenderer.getWidth(text) + 16;
        GuiDraw.glassPanel(g, -w / 2, -10, w, 18, 9,
                Style.alpha(Style.PANEL, a),
                Style.alpha(Style.ACCENT_GLOW, a));
        g.drawCenteredTextWithShadow(mc.textRenderer, text, 0, -5, Style.alpha(Style.ACCENT, a));
        g.getMatrices().popMatrix();
    }
}
