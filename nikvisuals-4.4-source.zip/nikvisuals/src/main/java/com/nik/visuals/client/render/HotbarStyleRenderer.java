package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class HotbarStyleRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.hotbarStyle) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int baseX = sw / 2 - 91;
        int y = sh - 22;
        int selected;
        try { selected = mc.player.getInventory().getSelectedSlot(); }
        catch (Throwable t) { selected = 0; }

        // thin frame
        g.fill(baseX - 1, y - 1, baseX + 182, y, Style.alpha(Style.ACCENT, 0.55f));
        g.fill(baseX - 1, y + 20, baseX + 182, y + 21, Style.alpha(Style.ACCENT, 0.35f));

        int sx = baseX + selected * 20;
        GuiDraw.fillRounded(g, sx, y - 1, 20, 22, 3, Style.alpha(Style.ACCENT, 0.25f));
        g.fill(sx, y - 1, sx + 20, y, Style.ACCENT);
    }
}
