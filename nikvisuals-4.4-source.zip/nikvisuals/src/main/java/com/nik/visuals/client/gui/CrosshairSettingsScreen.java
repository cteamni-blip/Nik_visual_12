package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Dedicated crosshair editor: palette, rotation slider, bars, sizes.
 */
public class CrosshairSettingsScreen extends Screen {
    private static final int[] PALETTE = {
            0xFFFFFFFF, 0xFFE8E8E8, 0xFFB0B0B0,
            0xFF3DCC7A, 0xFF55FFAA, 0xFF1A8F5A,
            0xFF55AAFF, 0xFF3399FF, 0xFF1A6ACC,
            0xFFFF5555, 0xFFFF8844, 0xFFFFCC33,
            0xFFFF66AA, 0xFFCC66FF, 0xFFAA88FF
    };

    private final Screen parent;
    private float openA;
    private int px, py, pw, ph;
    private int dragSlider = -1; // 0 angle, 1 size, 2 gap, 3 thick, 4 dot

    public CrosshairSettingsScreen(Screen parent) {
        super(Text.literal("Прицел"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        openA = 0f;
        pw = 300;
        ph = 280;
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        ModConfig.customCrosshair = true;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        openA = Anim.approach(openA, 1f, 0.16f);
        float a = Anim.easeOutCubic(openA);

        g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (150 * a)));
        GuiDraw.fillRounded(g, px, py, pw, ph, 10, Style.alpha(Style.PANEL, a));
        g.fill(px, py, px + pw, py + 1, Style.alpha(Style.ACCENT, a * 0.5f));

        g.drawText(textRenderer, "Настройка прицела", px + 14, py + 12, Style.alpha(Style.TEXT, a), false);
        g.drawText(textRenderer, "ESC — назад", px + pw - 70, py + 12, Style.alpha(Style.TEXT_DIM, a), false);

        // Preview box
        int prevX = px + 14;
        int prevY = py + 32;
        int prevS = 72;
        GuiDraw.fillRounded(g, prevX, prevY, prevS, prevS, 8, Style.alpha(0xFF0A0A0A, a));
        drawPreview(g, prevX + prevS / 2, prevY + prevS / 2, a);

        // Enable toggle
        int tx = prevX + prevS + 14;
        int ty = prevY + 4;
        g.drawText(textRenderer, "Включён", tx, ty, Style.alpha(Style.TEXT, a), false);
        GuiDraw.toggle(g, tx + 70, ty - 1, 22, 12, ModConfig.customCrosshair ? 1f : 0f,
                Style.alpha(Style.ACCENT, a), Style.alpha(Style.TRACK_OFF, a), Style.alpha(Style.KNOB, a));

        // Part toggles — ordered
        String[] partNames = {"Точка", "Обводка", "Верх", "Низ", "Лево", "Право"};
        boolean[] parts = {
                ModConfig.crosshairDot, ModConfig.crosshairOutline,
                ModConfig.crosshairTop, ModConfig.crosshairBottom,
                ModConfig.crosshairLeft, ModConfig.crosshairRight
        };
        for (int i = 0; i < 6; i++) {
            int row = i / 2;
            int col = i % 2;
            int x = tx + col * 100;
            int y = ty + 22 + row * 18;
            g.drawText(textRenderer, partNames[i], x, y, Style.alpha(Style.TEXT_DIM, a), false);
            GuiDraw.toggle(g, x + 52, y - 1, 22, 12, parts[i] ? 1f : 0f,
                    Style.alpha(Style.ACCENT, a), Style.alpha(Style.TRACK_OFF, a), Style.alpha(Style.KNOB, a));
        }

        // Color palette
        int palY = prevY + prevS + 14;
        g.drawText(textRenderer, "Цвет", px + 14, palY, Style.alpha(Style.TEXT, a), false);
        int cell = 14;
        int gap = 3;
        for (int i = 0; i < PALETTE.length; i++) {
            int cx = px + 14 + (i % 8) * (cell + gap);
            int cy = palY + 14 + (i / 8) * (cell + gap);
            boolean sel = (ModConfig.crosshairColor & 0xFFFFFF) == (PALETTE[i] & 0xFFFFFF);
            GuiDraw.fillRounded(g, cx - 1, cy - 1, cell + 2, cell + 2, 3,
                    Style.alpha(sel ? Style.ACCENT : 0xFF222222, a));
            g.fill(cx, cy, cx + cell, cy + cell, 0xFF000000 | (PALETTE[i] & 0xFFFFFF));
        }

        // Sliders — ordered
        int sy = palY + 50;
        drawSlider(g, px + 14, sy, pw - 28, "Поворот", ModConfig.crosshairAngle, 0, 45, "°", a, mx, my, 0);
        drawSlider(g, px + 14, sy + 28, pw - 28, "Размер", ModConfig.crosshairSize, 1, 16, "", a, mx, my, 1);
        drawSlider(g, px + 14, sy + 56, pw - 28, "Зазор", ModConfig.crosshairGap, 0, 12, "", a, mx, my, 2);
        drawSlider(g, px + 14, sy + 84, pw - 28, "Толщина", ModConfig.crosshairThickness, 1, 4, "", a, mx, my, 3);
        drawSlider(g, px + 14, sy + 112, pw - 28, "Точка", ModConfig.crosshairDotSize, 0, 6, "", a, mx, my, 4);

        // Done
        int bx = px + pw / 2 - 40;
        int by = py + ph - 24;
        boolean hov = mx >= bx && mx <= bx + 80 && my >= by && my <= by + 14;
        GuiDraw.fillRounded(g, bx, by, 80, 14, 4, Style.alpha(hov ? Style.ACCENT : 0xFF1E1E1E, a));
        g.drawCenteredTextWithShadow(textRenderer, "Готово", bx + 40, by + 3, Style.alpha(Style.TEXT, a));

        super.render(g, mx, my, delta);
    }

    private void drawSlider(DrawContext g, int x, int y, int w, String label, int value, int min, int max,
                            String suffix, float a, int mx, int my, int id) {
        g.drawText(textRenderer, label, x, y, Style.alpha(Style.TEXT_DIM, a), false);
        String val = value + suffix;
        g.drawText(textRenderer, val, x + w - textRenderer.getWidth(val), y, Style.alpha(Style.TEXT, a), false);
        int trackY = y + 12;
        int trackH = 4;
        GuiDraw.fillRounded(g, x, trackY, w, trackH, 2, Style.alpha(Style.TRACK_OFF, a));
        float t = (max == min) ? 0f : (value - min) / (float) (max - min);
        int fillW = Math.max(4, (int) (w * t));
        GuiDraw.fillRounded(g, x, trackY, fillW, trackH, 2, Style.alpha(Style.ACCENT, a));
        int knobX = x + fillW - 3;
        GuiDraw.fillSoftCircle(g, knobX + 3, trackY + trackH / 2, 4, Style.alpha(Style.KNOB, a));
    }

    private void drawPreview(DrawContext g, int cx, int cy, float a) {
        int col = 0xFF000000 | (ModConfig.crosshairColor & 0xFFFFFF);
        int size = Math.max(2, ModConfig.crosshairSize);
        int gap = Math.max(0, ModConfig.crosshairGap);
        int th = Math.max(1, ModConfig.crosshairThickness);
        // simple non-rotated preview for clarity
        if (ModConfig.crosshairLeft)
            g.fill(cx - gap - size, cy - th / 2, cx - gap, cy - th / 2 + th, col);
        if (ModConfig.crosshairRight)
            g.fill(cx + gap, cy - th / 2, cx + gap + size, cy - th / 2 + th, col);
        if (ModConfig.crosshairTop)
            g.fill(cx - th / 2, cy - gap - size, cx - th / 2 + th, cy - gap, col);
        if (ModConfig.crosshairBottom)
            g.fill(cx - th / 2, cy + gap, cx - th / 2 + th, cy + gap + size, col);
        if (ModConfig.crosshairDot && ModConfig.crosshairDotSize > 0) {
            int d = Math.max(1, ModConfig.crosshairDotSize);
            g.fill(cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d, col);
        }
    }

    private int sliderValueAt(int mx, int x, int w, int min, int max) {
        float t = (mx - x) / (float) w;
        t = Math.max(0f, Math.min(1f, t));
        return min + Math.round(t * (max - min));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();

        // Done
        int bx = px + pw / 2 - 40;
        int by = py + ph - 24;
        if (mx >= bx && mx <= bx + 80 && my >= by && my <= by + 14) {
            close();
            return true;
        }

        // Enable
        int prevS = 72;
        int tx = px + 14 + prevS + 14;
        int ty = py + 32 + 4;
        if (mx >= tx + 70 && mx <= tx + 92 && my >= ty - 1 && my <= ty + 11) {
            ModConfig.customCrosshair = !ModConfig.customCrosshair;
            ModConfig.save();
            return true;
        }

        // Parts
        boolean[] was = {
                ModConfig.crosshairDot, ModConfig.crosshairOutline,
                ModConfig.crosshairTop, ModConfig.crosshairBottom,
                ModConfig.crosshairLeft, ModConfig.crosshairRight
        };
        for (int i = 0; i < 6; i++) {
            int row = i / 2;
            int col = i % 2;
            int x = tx + col * 100 + 52;
            int y = ty + 22 + row * 18 - 1;
            if (mx >= x && mx <= x + 22 && my >= y && my <= y + 12) {
                switch (i) {
                    case 0 -> ModConfig.crosshairDot = !ModConfig.crosshairDot;
                    case 1 -> ModConfig.crosshairOutline = !ModConfig.crosshairOutline;
                    case 2 -> ModConfig.crosshairTop = !ModConfig.crosshairTop;
                    case 3 -> ModConfig.crosshairBottom = !ModConfig.crosshairBottom;
                    case 4 -> ModConfig.crosshairLeft = !ModConfig.crosshairLeft;
                    case 5 -> ModConfig.crosshairRight = !ModConfig.crosshairRight;
                }
                ModConfig.save();
                return true;
            }
        }

        // Palette
        int palY = py + 32 + 72 + 14;
        int cell = 14, gap = 3;
        for (int i = 0; i < PALETTE.length; i++) {
            int cx = px + 14 + (i % 8) * (cell + gap);
            int cy = palY + 14 + (i / 8) * (cell + gap);
            if (mx >= cx && mx <= cx + cell && my >= cy && my <= cy + cell) {
                ModConfig.crosshairColor = PALETTE[i];
                ModConfig.save();
                return true;
            }
        }

        // Sliders
        int sy = palY + 50;
        int[] mins = {0, 1, 0, 1, 0};
        int[] maxs = {45, 16, 12, 4, 6};
        for (int i = 0; i < 5; i++) {
            int y = sy + i * 28 + 10;
            int x = px + 14;
            int w = pw - 28;
            if (mx >= x && mx <= x + w && my >= y - 4 && my <= y + 10) {
                dragSlider = i;
                applySlider(i, (int) mx, x, w, mins[i], maxs[i]);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void applySlider(int id, int mx, int x, int w, int min, int max) {
        int v = sliderValueAt(mx, x, w, min, max);
        switch (id) {
            case 0 -> ModConfig.crosshairAngle = v;
            case 1 -> ModConfig.crosshairSize = v;
            case 2 -> ModConfig.crosshairGap = v;
            case 3 -> ModConfig.crosshairThickness = v;
            case 4 -> ModConfig.crosshairDotSize = v;
        }
        ModConfig.save();
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragSlider >= 0) {
            int[] mins = {0, 1, 0, 1, 0};
            int[] maxs = {45, 16, 12, 4, 6};
            int palY = py + 32 + 72 + 14;
            int sy = palY + 50;
            int x = px + 14;
            int w = pw - 28;
            applySlider(dragSlider, (int) click.x(), x, w, mins[dragSlider], maxs[dragSlider]);
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragSlider = -1;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
