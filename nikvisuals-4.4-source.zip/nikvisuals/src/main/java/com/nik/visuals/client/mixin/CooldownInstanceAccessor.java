package com.nik.visuals.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = {
        "net.minecraft.entity.player.ItemCooldownManager$Entry",
        "net.minecraft.entity.player.ItemCooldownManager$Cooldown"
})
public interface CooldownInstanceAccessor {
    @Accessor("endTick")
    int getEndTick();

    @Accessor("startTick")
    int getStartTick();
}
