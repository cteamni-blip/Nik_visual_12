package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class CrosshairRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.customCrosshair) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;

        int col = 0xFF000000 | (ModConfig.crosshairColor & 0xFFFFFF);
        int outline = ModConfig.crosshairOutline ? 0xFF000000 : 0;
        int size = clamp(ModConfig.crosshairSize, 1, 16);
        int gap = clamp(ModConfig.crosshairGap, 0, 12);
        int th = clamp(ModConfig.crosshairThickness, 1, 4);
        int dot = clamp(ModConfig.crosshairDotSize, 0, 6);
        float angle = ModConfig.crosshairAngle * (float) Math.PI / 180f;

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(cx, cy);
        // Matrix3x2fStack may not have rotate - approximate with rotated arms via math
        // Draw in rotated coordinates using cos/sin for each arm endpoint

        if (ModConfig.crosshairLeft) {
            drawArm(g, -gap - size, -th / 2f, size, th, angle, col, outline);
        }
        if (ModConfig.crosshairRight) {
            drawArm(g, gap + 1, -th / 2f, size, th, angle, col, outline);
        }
        if (ModConfig.crosshairTop) {
            drawArm(g, -th / 2f, -gap - size, th, size, angle, col, outline);
        }
        if (ModConfig.crosshairBottom) {
            drawArm(g, -th / 2f, gap + 1, th, size, angle, col, outline);
        }
        if (ModConfig.crosshairDot && dot > 0) {
            int d = dot;
            if (outline != 0) fill(g, -d / 2 - 1, -d / 2 - 1, d + 2, d + 2, outline, angle);
            fill(g, -d / 2, -d / 2, d, d, col, angle);
        }
        g.getMatrices().popMatrix();
    }

    private void drawArm(DrawContext g, float x, float y, float w, float h, float angle, int col, int outline) {
        if (outline != 0) {
            fill(g, x - 1, y - 1, w + 2, h + 2, outline, angle);
        }
        fill(g, x, y, w, h, col, angle);
    }

    /** Fill axis-aligned box then rotate points around origin via 4-corner approx as pixels */
    private void fill(DrawContext g, float x, float y, float w, float h, int col, float angle) {
        if (w <= 0 || h <= 0) return;
        if (Math.abs(angle) < 0.001f) {
            g.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), col);
            return;
        }
        // rasterize rotated rectangle (small)
        float cos = (float) Math.cos(angle);
        float sin = (float) Math.sin(angle);
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        float[] xs = {x, x + w, x + w, x};
        float[] ys = {y, y, y + h, y + h};
        float[] rx = new float[4], ry = new float[4];
        for (int i = 0; i < 4; i++) {
            rx[i] = xs[i] * cos - ys[i] * sin;
            ry[i] = xs[i] * sin + ys[i] * cos;
            minX = Math.min(minX, (int) Math.floor(rx[i]));
            maxX = Math.max(maxX, (int) Math.ceil(rx[i]));
            minY = Math.min(minY, (int) Math.floor(ry[i]));
            maxY = Math.max(maxY, (int) Math.ceil(ry[i]));
        }
        for (int py = minY; py <= maxY; py++) {
            for (int px = minX; px <= maxX; px++) {
                // inverse rotate point into local
                float lx = px * cos + py * sin;
                float ly = -px * sin + py * cos;
                if (lx >= x && lx < x + w && ly >= y && ly < y + h) {
                    g.fill(px, py, px + 1, py + 1, col);
                }
            }
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
